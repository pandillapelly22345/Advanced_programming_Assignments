A bullet list of any assumptions that were made.

1. After login successful it will ask for balance. The balance should be given which we have given at the time of registration. This balance will check that the correct balance provided otherwise it will give an error.

2. By Default Minor has discount 10% and Senior has 20% discount.

3. Here minor is age<18 and senior is age>60.

4. Exploring the Zoo option is free for everyone, and Visitor dont need any Membership for this.

5. For visiting animals visitors dont need to buy any tickets, but only basic visitor and premium visitor can visit the animals.

6. while buying membership it will ask for name, you should give the registered name, otherwise it will give an error (same as in point 1).

7. Input should be given in correct form i.e - when asking for a price or any numerical value only numbers should be given as a input

HOME_FOLDER = Assignment-2

All the commands should be run on the terminal in the HOME_FOLDER unless otherwise specified.

0) Download the folder from Classroom and unzip.
1) mvn clean 
2) mvn compile
3) mvn package
4) java -jar .\target\Assignment-2-1.0-SNAPSHOT.jar