public interface Experience {
    void buyMembership();
    void buyTickets();
    void visitAttraction();

}
